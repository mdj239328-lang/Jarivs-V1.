package com.jarvis.ai

import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.mapNotNull

object AiConfig {
    /** Change this string if Google retires the model (see Firebase AI Logic "models" page). */
    const val MODEL = "gemini-3.5-flash"

    const val MAX_TURNS = 40

    const val SYSTEM = """You are JARVIS AI, a helpful personal assistant inside an Android app.
Reply in the same language the user writes in (Bengali or English; if they mix, follow their main language).
Keep answers clear and reasonably short because the screen is small. Use plain text; avoid heavy markdown.
You have NO internet access, NO live data, and NO access to the user's phone, contacts, files or apps in this chat.
If asked for current information (news, prices, weather, time), say you cannot verify it.
You only know what is said in this conversation; never claim to remember anything from other chats."""
}

class AiClient {
    private val model by lazy {
        Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
            modelName = AiConfig.MODEL,
            systemInstruction = content { text(AiConfig.SYSTEM) }
        )
    }

    /**
     * Streams the answer to [prompt], using [history] (messages before the prompt) as context.
     * History is rebuilt on every call, so retry and reopened chats keep their context.
     */
    fun stream(history: List<Message>, prompt: String): Flow<String> {
        // Gemini needs strictly alternating turns that start with "user" and end with "model".
        val turns = ArrayList<Pair<Boolean, String>>()
        for (m in history) {
            if (m.isError || m.text.isBlank()) continue
            if (turns.isNotEmpty() && turns.last().first == m.fromUser) {
                turns[turns.lastIndex] = m.fromUser to m.text
            } else {
                turns.add(m.fromUser to m.text)
            }
        }
        while (turns.size > AiConfig.MAX_TURNS) turns.removeAt(0)
        while (turns.isNotEmpty() && !turns.first().first) turns.removeAt(0)
        while (turns.isNotEmpty() && turns.last().first) turns.removeAt(turns.lastIndex)

        val past = turns.map { (fromUser, t) ->
            content(if (fromUser) "user" else "model") { text(t) }
        }
        val chat = model.startChat(past)
        return chat.sendMessageStream(prompt).mapNotNull { it.text }
    }
}
