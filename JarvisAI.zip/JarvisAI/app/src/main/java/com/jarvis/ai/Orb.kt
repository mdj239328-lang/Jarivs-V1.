package com.jarvis.ai

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale

/** Lightweight circular JARVIS animation. Pulses stronger while the AI answers or the mic listens. */
@Composable
fun JarvisOrb(modifier: Modifier = Modifier, active: Boolean = false) {
    val color = MaterialTheme.colorScheme.primary
    val t = rememberInfiniteTransition(label = "orb")
    val rot by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(10000, easing = LinearEasing)),
        label = "rot"
    )
    val pulse by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulse"
    )
    val amount by animateFloatAsState(if (active) 1f else 0.25f, label = "amount")
    val s = 1f - 0.06f * pulse * amount

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val sw = r * 0.04f
        scale(s) {
            drawCircle(color.copy(alpha = 0.25f), r * 0.97f, style = Stroke(sw))
            rotate(rot) {
                val a = r * 0.8f
                for (start in listOf(0f, 180f)) {
                    drawArc(
                        color, start, 90f, false,
                        topLeft = Offset(c.x - a, c.y - a), size = Size(a * 2, a * 2),
                        style = Stroke(sw * 1.8f, cap = StrokeCap.Round)
                    )
                }
            }
            rotate(-rot * 1.5f) {
                val a = r * 0.58f
                for (start in listOf(30f, 210f)) {
                    drawArc(
                        color.copy(alpha = 0.7f), start, 60f, false,
                        topLeft = Offset(c.x - a, c.y - a), size = Size(a * 2, a * 2),
                        style = Stroke(sw * 1.4f, cap = StrokeCap.Round)
                    )
                }
            }
            drawCircle(color.copy(alpha = 0.18f), r * 0.34f)
            drawCircle(color, r * 0.2f)
        }
    }
}
