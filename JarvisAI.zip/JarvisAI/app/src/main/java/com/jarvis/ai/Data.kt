package com.jarvis.ai

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Message(val id: Long, val fromUser: Boolean, val text: String, val isError: Boolean = false)

data class Chat(val id: String, val title: String, val updatedAt: Long, val messages: List<Message>)

/** User preferences (stored locally). Nothing here is sent anywhere. */
class AppSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    var consentAsked by mutableStateOf(sp.getBoolean("consentAsked", false))
        private set
    var saveHistory by mutableStateOf(sp.getBoolean("saveHistory", false))
        private set
    var theme by mutableStateOf(sp.getString("theme", "dark") ?: "dark")
        private set
    var speechRate by mutableStateOf(sp.getFloat("rate", 1.0f))
        private set
    var voiceName by mutableStateOf(sp.getString("voice", "") ?: "")
        private set
    var autoSpeak by mutableStateOf(sp.getBoolean("autoSpeak", false))
        private set
    var micLang by mutableStateOf(sp.getString("micLang", "bn-BD") ?: "bn-BD")
        private set

    fun answerConsent(save: Boolean) {
        consentAsked = true
        saveHistory = save
        sp.edit().putBoolean("consentAsked", true).putBoolean("saveHistory", save).apply()
    }

    fun setSaveHistory(v: Boolean) {
        saveHistory = v
        sp.edit().putBoolean("saveHistory", v).apply()
    }

    fun setTheme(v: String) {
        theme = v
        sp.edit().putString("theme", v).apply()
    }

    fun setSpeechRate(v: Float) {
        speechRate = v
        sp.edit().putFloat("rate", v).apply()
    }

    fun setVoiceName(v: String) {
        voiceName = v
        sp.edit().putString("voice", v).apply()
    }

    fun setAutoSpeak(v: Boolean) {
        autoSpeak = v
        sp.edit().putBoolean("autoSpeak", v).apply()
    }

    fun setMicLang(v: String) {
        micLang = v
        sp.edit().putString("micLang", v).apply()
    }
}

/** Saves each chat as a private JSON file inside the app's internal storage. */
class ChatStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "chats").apply { mkdirs() }

    fun save(c: Chat) {
        val arr = JSONArray()
        c.messages.forEach {
            arr.put(JSONObject().put("id", it.id).put("u", it.fromUser).put("t", it.text).put("e", it.isError))
        }
        val o = JSONObject().put("id", c.id).put("title", c.title).put("at", c.updatedAt).put("m", arr)
        File(dir, "${c.id}.json").writeText(o.toString())
    }

    fun list(): List<Chat> =
        dir.listFiles()
            ?.mapNotNull { f -> runCatching { parse(f.readText()) }.getOrNull() }
            ?.sortedByDescending { it.updatedAt }
            ?: emptyList()

    fun delete(id: String) {
        File(dir, "$id.json").delete()
    }

    fun deleteAll() {
        dir.listFiles()?.forEach { it.delete() }
    }

    private fun parse(s: String): Chat {
        val o = JSONObject(s)
        val a = o.getJSONArray("m")
        val msgs = (0 until a.length()).map {
            val j = a.getJSONObject(it)
            Message(j.getLong("id"), j.getBoolean("u"), j.getString("t"), j.optBoolean("e", false))
        }
        return Chat(o.getString("id"), o.getString("title"), o.getLong("at"), msgs)
    }
}
