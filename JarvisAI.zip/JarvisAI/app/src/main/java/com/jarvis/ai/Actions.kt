package com.jarvis.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore

/**
 * Supported phone actions. Each one just opens a standard Android screen or app through a normal intent.
 * JARVIS does not control other apps, read the screen, or bypass any permission.
 */
data class PhoneAction(
    val title: String,
    val desc: String,
    val inputLabel: String?,
    val run: (Context, String) -> Boolean,
)

private fun launch(ctx: Context, intent: Intent): Boolean = try {
    ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    true
} catch (e: Exception) {
    false
}

fun phoneActions(ctx: Context): List<PhoneAction> {
    val list = mutableListOf(
        PhoneAction("Open camera", "Opens your camera app", null) { c, _ ->
            launch(c, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        },
        PhoneAction("Open Settings", "Opens Android Settings", null) { c, _ ->
            launch(c, Intent(android.provider.Settings.ACTION_SETTINGS))
        },
        PhoneAction("Wi-Fi settings", "Opens the Wi-Fi screen (you switch it yourself)", null) { c, _ ->
            launch(c, Intent(android.provider.Settings.ACTION_WIFI_SETTINGS))
        },
        PhoneAction("Bluetooth settings", "Opens the Bluetooth screen", null) { c, _ ->
            launch(c, Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
        },
        PhoneAction("Search the web", "Opens a Google search in your browser", "Search for…") { c, q ->
            q.isNotBlank() && launch(
                c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q.trim())))
            )
        },
        PhoneAction("Find on map", "Opens a map app for a place", "Place or address…") { c, q ->
            q.isNotBlank() && launch(c, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q.trim()))))
        },
        PhoneAction("Open dialer", "Opens the dialer with the number filled in. It does NOT place the call.", "Phone number…") { c, n ->
            val num = n.filter { it.isDigit() || it == '+' }
            num.isNotEmpty() && launch(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
        },
        PhoneAction("Set alarm", "Creates an alarm in your clock app", "Time as HH:MM (24-hour), e.g. 06:30") { c, t ->
            val p = t.trim().split(":")
            val h = p.getOrNull(0)?.toIntOrNull()
            val m = p.getOrNull(1)?.toIntOrNull()
            if (h == null || m == null || h !in 0..23 || m !in 0..59) {
                false
            } else {
                launch(
                    c, Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, h)
                        .putExtra(AlarmClock.EXTRA_MINUTES, m)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS AI")
                )
            }
        },
    )
    listOf(
        "YouTube" to "com.google.android.youtube",
        "WhatsApp" to "com.whatsapp",
        "Facebook" to "com.facebook.katana",
        "Messenger" to "com.facebook.orca",
        "Chrome" to "com.android.chrome",
    ).forEach { (name, pkg) ->
        if (ctx.packageManager.getLaunchIntentForPackage(pkg) != null) {
            list.add(PhoneAction("Open $name", "Opens the $name app", null) { c, _ ->
                val i = c.packageManager.getLaunchIntentForPackage(pkg)
                i != null && launch(c, i)
            })
        }
    }
    return list
}
