package com.jarvis.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

fun toast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
}

@Composable
fun ChatScreen(vm: ChatViewModel, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val listener = vm.listener
    val msgs = vm.messages
    val listState = rememberLazyListState()
    var input by rememberSaveable { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }

    vm.speaker.notify = { toast(ctx, it) }

    val startMic: () -> Unit = {
        if (!listener.available()) {
            toast(ctx, "এই ফোনে ভয়েস ইনপুট পাওয়া যায়নি, টাইপ করুন।\nSpeech recognition is unavailable here; please type.")
        } else {
            vm.speaker.stop()
            listener.start(vm.settings.micLang, { vm.send(it) }, { toast(ctx, it) })
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startMic()
        else toast(ctx, "মাইক্রোফোন অনুমতি ছাড়া ভয়েস কাজ করবে না; টাইপ করে ব্যবহার করুন।\nMic permission denied; you can still type.")
    }
    val onMic: () -> Unit = {
        if (listener.listening) {
            listener.stop()
        } else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startMic()
        } else {
            permission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(msgs.size, msgs.lastOrNull()?.text?.length) {
        if (msgs.isNotEmpty()) listState.scrollToItem(msgs.lastIndex)
    }

    Column(Modifier.fillMaxSize()) {
        // Top bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            JarvisOrb(Modifier.size(36.dp), active = vm.generating || listener.listening)
            Text(
                "  JARVIS AI", fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
                color = MaterialTheme.colorScheme.primary, fontSize = 18.sp,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { vm.newChat() }) { Text("＋ New") }
            Box {
                TextButton(onClick = { menu = true }) { Text("⋮", fontSize = 20.sp) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Clear chat / চ্যাট মুছুন") }, onClick = { menu = false; vm.clearChat() })
                    DropdownMenuItem(text = { Text("Chat history / হিস্টোরি") }, onClick = { menu = false; go(Screen.History) })
                    DropdownMenuItem(text = { Text("Phone actions") }, onClick = { menu = false; go(Screen.Actions) })
                    DropdownMenuItem(text = { Text("Settings / সেটিংস") }, onClick = { menu = false; go(Screen.Settings) })
                }
            }
        }

        // Messages
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (msgs.isEmpty()) {
                EmptyState(vm)
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(msgs, key = { it.id }) { m ->
                        Bubble(
                            m = m,
                            isLast = m.id == msgs.last().id,
                            vm = vm,
                            onCopy = {
                                clipboard.setText(AnnotatedString(m.text))
                                toast(ctx, "Copied / কপি হয়েছে")
                            }
                        )
                    }
                }
            }
        }

        if (listener.listening) {
            Text(
                if (listener.partial.isEmpty()) "🎙 শুনছি… / Listening…" else listener.partial,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        // Input area
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("মেসেজ লিখুন / Message…") },
                maxLines = 4,
                shape = RoundedCornerShape(24.dp)
            )
            TextButton(
                onClick = { vm.settings.setMicLang(if (vm.settings.micLang == "bn-BD") "en-US" else "bn-BD") },
                modifier = Modifier.widthIn(min = 44.dp)
            ) { Text(if (vm.settings.micLang == "bn-BD") "বাং" else "EN", fontWeight = FontWeight.Bold) }
            FilledIconButton(onClick = onMic) { Text(if (listener.listening) "■" else "🎙") }
            if (vm.generating) {
                FilledIconButton(onClick = { vm.stop() }) { Text("■") }
            } else {
                FilledIconButton(
                    onClick = { vm.send(input); input = "" },
                    enabled = input.isNotBlank()
                ) { Text("➤") }
            }
        }
    }
}

@Composable
private fun EmptyState(vm: ChatViewModel) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        JarvisOrb(Modifier.size(140.dp))
        Spacer(Modifier.size(16.dp))
        Text(
            "আমি JARVIS AI। বাংলা বা English-এ কথা বলুন।",
            textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold, fontSize = 18.sp
        )
        Text(
            "I'm JARVIS AI. Ask me anything in Bengali or English.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )
        listOf(
            "আজকের জন্য একটি সহজ পড়ার রুটিন বানিয়ে দাও",
            "Explain how the internet works in simple words",
            "Teach me 5 useful English phrases for a job interview",
        ).forEach { s ->
            OutlinedButton(
                onClick = { vm.send(s) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
            ) { Text(s, textAlign = TextAlign.Center) }
        }
    }
}

@Composable
private fun Bubble(m: Message, isLast: Boolean, vm: ChatViewModel, onCopy: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val user = m.fromUser
    val container = when {
        user -> cs.primary
        m.isError -> cs.errorContainer
        else -> cs.surfaceVariant
    }
    val textColor = when {
        user -> cs.onPrimary
        m.isError -> cs.onErrorContainer
        else -> cs.onSurface
    }
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (user) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = container,
            shape = RoundedCornerShape(
                topStart = 18.dp, topEnd = 18.dp,
                bottomEnd = if (user) 4.dp else 18.dp,
                bottomStart = if (user) 18.dp else 4.dp
            ),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Box(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                if (!user && m.text.isEmpty()) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    SelectionContainer { Text(m.text, color = textColor) }
                }
            }
        }
        if (!user && m.text.isNotEmpty() && !(vm.generating && isLast)) {
            Row {
                if (!m.isError) {
                    TextButton(onClick = onCopy) { Text("Copy", fontSize = 13.sp) }
                    TextButton(onClick = {
                        if (vm.speaker.speaking) vm.speaker.stop()
                        else vm.speaker.speak(m.text, vm.settings.speechRate, vm.settings.voiceName)
                    }) { Text(if (vm.speaker.speaking) "⏹ Stop" else "🔊 Speak", fontSize = 13.sp) }
                }
                if (isLast) TextButton(onClick = { vm.retry() }) { Text("↻ Retry", fontSize = 13.sp) }
            }
        }
    }
}
