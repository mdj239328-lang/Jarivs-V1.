package com.jarvis.ai

import android.app.Application
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    val settings = AppSettings(app)
    val speaker = Speaker(app)
    val listener = Listener(app)

    private val store = ChatStore(app)
    private val ai = AiClient()

    val messages = mutableStateListOf<Message>()

    var generating by mutableStateOf(false)
        private set
    var history by mutableStateOf<List<Chat>>(emptyList())
        private set

    private var chatId = UUID.randomUUID().toString()
    private var nextId = 1L
    private var job: Job? = null

    // ---------- chat ----------

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || generating) return
        val past = messages.toList()
        messages.add(Message(nextId++, true, t))
        run(past, t)
    }

    fun retry() {
        if (generating) return
        val lastUser = messages.indexOfLast { it.fromUser }
        if (lastUser < 0) return
        val prompt = messages[lastUser].text
        while (messages.size > lastUser + 1) messages.removeAt(messages.lastIndex)
        run(messages.take(lastUser), prompt)
    }

    fun stop() {
        job?.cancel()
    }

    private fun run(past: List<Message>, prompt: String) {
        speaker.stop()
        generating = true
        val aiId = nextId++
        messages.add(Message(aiId, false, ""))
        job = viewModelScope.launch {
            val sb = StringBuilder()
            var ok = false
            try {
                ai.stream(past, prompt).collect { chunk ->
                    sb.append(chunk)
                    update(aiId, sb.toString(), false)
                }
                if (sb.isEmpty()) {
                    update(aiId, emptyAnswerMessage(), true)
                } else {
                    ok = true
                }
            } catch (e: CancellationException) {
                if (sb.isEmpty()) messages.removeAll { it.id == aiId }
                throw e
            } catch (e: Exception) {
                val msg = friendly(e)
                if (sb.isEmpty()) update(aiId, msg, true) else update(aiId, sb.toString() + "\n\n⚠ " + msg, false)
            } finally {
                generating = false
                persist()
            }
            if (ok && settings.autoSpeak) speaker.speak(sb.toString(), settings.speechRate, settings.voiceName)
        }
    }

    private fun update(id: Long, text: String, error: Boolean) {
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text, isError = error)
    }

    fun newChat() {
        stop()
        speaker.stop()
        messages.clear()
        chatId = UUID.randomUUID().toString()
    }

    fun clearChat() {
        stop()
        speaker.stop()
        val old = chatId
        messages.clear()
        viewModelScope.launch(Dispatchers.IO) {
            store.delete(old)
            if (settings.saveHistory) history = store.list()
        }
    }

    // ---------- history ----------

    fun refreshHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            history = if (settings.saveHistory) store.list() else emptyList()
        }
    }

    fun openChat(c: Chat) {
        stop()
        speaker.stop()
        messages.clear()
        messages.addAll(c.messages)
        chatId = c.id
        nextId = (c.messages.maxOfOrNull { it.id } ?: 0L) + 1
    }

    fun deleteChat(id: String) {
        if (id == chatId) newChat()
        viewModelScope.launch(Dispatchers.IO) {
            store.delete(id)
            history = store.list()
        }
    }

    fun deleteAllHistory() {
        newChat()
        viewModelScope.launch(Dispatchers.IO) {
            store.deleteAll()
            history = emptyList()
        }
    }

    private fun persist() {
        if (!settings.saveHistory) return
        val snapshot = messages.filter { it.text.isNotEmpty() }
        val firstUser = snapshot.firstOrNull { it.fromUser } ?: return
        val chat = Chat(
            chatId,
            firstUser.text.replace("\n", " ").take(40),
            System.currentTimeMillis(),
            snapshot
        )
        viewModelScope.launch(Dispatchers.IO) {
            store.save(chat)
            history = store.list()
        }
    }

    // ---------- errors ----------

    private fun online(): Boolean {
        val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java) ?: return false
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun emptyAnswerMessage() =
        "AI কোনো উত্তর দেয়নি। আবার চেষ্টা করুন।\nThe AI returned no answer. Please retry."

    private fun friendly(e: Throwable): String {
        if (!online()) {
            return "ইন্টারনেট সংযোগ নেই। সংযোগ চালু করে আবার চেষ্টা করুন।\nNo internet connection. Reconnect and tap Retry."
        }
        val s = (e::class.java.simpleName + " " + (e.message ?: "")).lowercase()
        return when {
            "quota" in s || "429" in s || "resource_exhausted" in s || ("rate" in s && "limit" in s) ->
                "ব্যবহারের সীমা শেষ হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।\nUsage limit reached. Please try again later."
            "app check" in s || "appcheck" in s || "403" in s || "permission" in s ||
                "unauthenticated" in s || "api key" in s || "not been used" in s ->
                "Firebase বা App Check সেটআপে সমস্যা। Settings → Security দেখুন।\nFirebase / App Check setup problem. Open Settings → Security."
            "safety" in s || "blocked" in s ->
                "নিরাপত্তা ফিল্টারের কারণে এই অনুরোধের উত্তর দেওয়া যায়নি।\nThis request was blocked by the safety filter."
            "timeout" in s || "unavailable" in s || "unknownhost" in s || "unable to resolve" in s ->
                "সার্ভারে পৌঁছানো যাচ্ছে না (নেটওয়ার্ক ধীর হতে পারে)। Retry চাপুন।\nCannot reach the server (slow network?). Tap Retry."
            else ->
                "সমস্যা হয়েছে: ${e.message?.take(160) ?: e::class.java.simpleName}\nSomething went wrong. Tap Retry."
        }
    }

    override fun onCleared() {
        speaker.shutdown()
        listener.release()
        super.onCleared()
    }
}
