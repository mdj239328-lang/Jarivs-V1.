package com.jarvis.ai

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            val vm: ChatViewModel = viewModel()
            val dark = when (vm.settings.theme) {
                "light" -> false
                "dark" -> true
                else -> isSystemInDarkTheme()
            }
            DisposableEffect(dark) {
                val style = if (dark) {
                    SystemBarStyle.dark(AndroidColor.TRANSPARENT)
                } else {
                    SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            JarvisTheme(dark) { JarvisApp(vm) }
        }
    }
}

enum class Screen { Chat, History, Settings, Actions }

@Composable
fun JarvisApp(vm: ChatViewModel) {
    var screen by rememberSaveable { mutableStateOf(Screen.Chat) }
    BackHandler(enabled = screen != Screen.Chat) { screen = Screen.Chat }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            when (screen) {
                Screen.Chat -> ChatScreen(vm) { screen = it }
                Screen.History -> HistoryScreen(vm, onBack = { screen = Screen.Chat }, onOpen = {
                    vm.openChat(it)
                    screen = Screen.Chat
                })
                Screen.Settings -> SettingsScreen(vm) { screen = Screen.Chat }
                Screen.Actions -> ActionsScreen { screen = Screen.Chat }
            }
        }
    }

    if (!vm.settings.consentAsked) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("চ্যাট হিস্টোরি সেভ করবেন? / Save chat history?") },
            text = {
                Text(
                    "আপনি চাইলে চ্যাট শুধু এই ফোনেই সেভ থাকবে এবং যেকোনো সময় মুছতে পারবেন। এটি AI-এর দীর্ঘমেয়াদি মেমরি নয়।\n\n" +
                        "Chats can be saved only on this phone and deleted anytime. This is not AI long-term memory.\n\n" +
                        "মনে রাখবেন: উত্তর তৈরির জন্য আপনার মেসেজ Google Gemini-তে (Firebase-এর মাধ্যমে) পাঠানো হয়। " +
                        "Your messages are sent to Google Gemini (via Firebase) to generate replies."
                )
            },
            confirmButton = { TextButton(onClick = { vm.settings.answerConsent(true) }) { Text("Save / সেভ করুন") } },
            dismissButton = { TextButton(onClick = { vm.settings.answerConsent(false) }) { Text("Don't save / সেভ নয়") } }
        )
    }
}
