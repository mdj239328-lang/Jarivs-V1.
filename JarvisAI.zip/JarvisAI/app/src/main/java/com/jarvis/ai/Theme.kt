package com.jarvis.ai

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp

val Electric = Color(0xFF00B4FF)

private val DarkColors = darkColorScheme(
    primary = Electric,
    onPrimary = Color.Black,
    background = Color(0xFF000000),
    onBackground = Color(0xFFE6F1FF),
    surface = Color(0xFF0B0F1A),
    onSurface = Color(0xFFE6F1FF),
    surfaceVariant = Color(0xFF121A2B),
    onSurfaceVariant = Color(0xFFB8C7DD),
    outline = Color(0xFF1E3A5F),
    errorContainer = Color(0xFF3A1215),
    onErrorContainer = Color(0xFFFFD9D9),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0070E0),
    onPrimary = Color.White,
    background = Color(0xFFF6F9FF),
    onBackground = Color(0xFF0A1220),
    surface = Color.White,
    onSurface = Color(0xFF0A1220),
    surfaceVariant = Color(0xFFE6EEFB),
    onSurfaceVariant = Color(0xFF3B4A63),
    outline = Color(0xFFB7C7E3),
    errorContainer = Color(0xFFFFE1E1),
    onErrorContainer = Color(0xFF5A1010),
)

@Composable
fun JarvisTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = Typography(
            bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
            bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
        ),
        content = content
    )
}
