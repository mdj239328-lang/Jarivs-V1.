package com.jarvis.ai

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.appcheck.FirebaseAppCheck
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 18.dp, bottom = 6.dp)
    )
}

// ---------------------------------------------------------------- History

@Composable
fun HistoryScreen(vm: ChatViewModel, onBack: () -> Unit, onOpen: (Chat) -> Unit) {
    var confirmAll by remember { mutableStateOf(false) }
    var confirmOne by remember { mutableStateOf<Chat?>(null) }
    LaunchedEffect(Unit) { vm.refreshHistory() }
    val fmt = remember { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Chat history / হিস্টোরি", onBack)
        Text(
            "এটি শুধু এই ফোনে সেভ করা চ্যাটের কপি; AI-এর দীর্ঘমেয়াদি মেমরি নয়। AI শুধু যে চ্যাটটি খোলা আছে তার মেসেজ দেখতে পায়।\n" +
                "These are saved copies on this phone, not AI long-term memory. The AI only sees the chat you have open.",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        if (!vm.settings.saveHistory) {
            Text(
                "History saving is OFF. Turn it on in Settings. / হিস্টোরি সেভ বন্ধ আছে; Settings থেকে চালু করুন।",
                modifier = Modifier.padding(16.dp)
            )
        } else if (vm.history.isEmpty()) {
            Text("No saved chats yet. / এখনও কোনো সেভ করা চ্যাট নেই।", modifier = Modifier.padding(16.dp))
        } else {
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.history, key = { it.id }) { c ->
                    Card(
                        onClick = { onOpen(c) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.title, maxLines = 1, fontWeight = FontWeight.SemiBold)
                                Text(
                                    fmt.format(Date(c.updatedAt)) + " · " + c.messages.size + " msgs",
                                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextButton(onClick = { confirmOne = c }) { Text("🗑") }
                        }
                    }
                }
            }
            OutlinedButton(onClick = { confirmAll = true }, modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                Text("Delete all history / সব হিস্টোরি মুছুন")
            }
        }
    }

    confirmOne?.let { c ->
        AlertDialog(
            onDismissRequest = { confirmOne = null },
            title = { Text("Delete this chat? / এই চ্যাট মুছবেন?") },
            text = { Text(c.title) },
            confirmButton = { TextButton(onClick = { vm.deleteChat(c.id); confirmOne = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmOne = null }) { Text("Cancel") } }
        )
    }
    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text("Delete ALL history? / সব মুছবেন?") },
            text = { Text("This cannot be undone. / এটি আর ফেরানো যাবে না।") },
            confirmButton = { TextButton(onClick = { vm.deleteAllHistory(); confirmAll = false }) { Text("Delete all") } },
            dismissButton = { TextButton(onClick = { confirmAll = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- Settings

private fun readDebugToken(ctx: android.content.Context): String? {
    val dir = File(ctx.applicationInfo.dataDir, "shared_prefs")
    dir.listFiles()
        ?.filter { it.name.contains("appcheck", true) && it.name.contains("debug", true) }
        ?.forEach { f ->
            val sp = ctx.getSharedPreferences(f.name.removeSuffix(".xml"), android.content.Context.MODE_PRIVATE)
            for ((k, v) in sp.all) {
                if (k.contains("secret", true) || k.contains("token", true)) return v.toString()
            }
        }
    return null
}

@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val s = vm.settings
    var voiceMenu by remember { mutableStateOf(false) }
    var confirmAll by remember { mutableStateOf(false) }
    var acStatus by remember { mutableStateOf("") }
    var debugToken by remember { mutableStateOf<String?>(null) }
    var tokenShown by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Settings / সেটিংস", onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {

            Section("Appearance / থিম")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("dark" to "Dark", "light" to "Light", "system" to "System").forEach { (k, label) ->
                    FilterChip(selected = s.theme == k, onClick = { s.setTheme(k) }, label = { Text(label) })
                }
            }

            Section("Voice / ভয়েস")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Speak answers automatically", Modifier.weight(1f))
                Switch(checked = s.autoSpeak, onCheckedChange = { s.setAutoSpeak(it) })
            }
            Text("Speech speed: " + String.format(Locale.US, "%.1fx", s.speechRate), modifier = Modifier.padding(top = 8.dp))
            Slider(value = s.speechRate, onValueChange = { s.setSpeechRate((it * 10).toInt() / 10f) }, valueRange = 0.5f..1.5f)
            Box {
                OutlinedButton(onClick = { voiceMenu = true }) {
                    Text("Voice: " + (s.voiceName.ifEmpty { "System default" }).take(28))
                }
                DropdownMenu(expanded = voiceMenu, onDismissRequest = { voiceMenu = false }) {
                    DropdownMenuItem(text = { Text("System default") }, onClick = { s.setVoiceName(""); voiceMenu = false })
                    vm.speaker.voices.take(40).forEach { v ->
                        DropdownMenuItem(
                            text = { Text("${v.locale.toLanguageTag()} · ${v.name}".take(48)) },
                            onClick = { s.setVoiceName(v.name); voiceMenu = false }
                        )
                    }
                }
            }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    vm.speaker.speak("Hello, I am JARVIS AI.", s.speechRate, s.voiceName)
                }) { Text("Test English") }
                OutlinedButton(onClick = {
                    vm.speaker.speak("হ্যালো, আমি জার্ভিস এআই।", s.speechRate, s.voiceName)
                }) { Text("Test বাংলা") }
            }
            Text("Microphone language (speech input):", Modifier.padding(top = 12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = s.micLang == "bn-BD", onClick = { s.setMicLang("bn-BD") }, label = { Text("বাংলা") })
                FilterChip(selected = s.micLang == "en-US", onClick = { s.setMicLang("en-US") }, label = { Text("English") })
            }
            Text(
                "Voice input and Bengali voices depend on the Google speech services installed on your phone, and voice input needs internet. " +
                    "ভয়েস ইনপুট ও বাংলা ভয়েস ফোনে থাকা Google speech সার্ভিসের উপর নির্ভর করে।",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)
            )

            Section("Privacy / গোপনীয়তা")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Save chat history on this phone", Modifier.weight(1f))
                Switch(checked = s.saveHistory, onCheckedChange = { s.setSaveHistory(it) })
            }
            OutlinedButton(onClick = { confirmAll = true }, modifier = Modifier.padding(top = 8.dp)) {
                Text("Delete all saved history")
            }
            Text(
                "• Chat history = copies of your chats stored only on this phone.\n" +
                    "• JARVIS has NO long-term AI memory: the AI sees only the chat you have open.\n" +
                    "• Your messages are sent to Google Gemini through Firebase to get answers.\n" +
                    "• Microphone audio is processed by Android's speech service only while you listen; JARVIS does not store audio. No contacts are read.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)
            )

            Section("AI & Security")
            Text("Model: ${AiConfig.MODEL} (via Firebase AI Logic)")
            Button(
                onClick = {
                    acStatus = "Checking…"
                    FirebaseAppCheck.getInstance().getAppCheckToken(false)
                        .addOnSuccessListener { acStatus = "✅ App Check token OK" }
                        .addOnFailureListener { acStatus = "❌ " + (it.message ?: it.javaClass.simpleName) }
                },
                modifier = Modifier.padding(top = 8.dp)
            ) { Text("Check App Check") }
            if (acStatus.isNotEmpty()) Text(acStatus, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))

            if (BuildConfig.USE_DEBUG_APPCHECK) {
                OutlinedButton(
                    onClick = {
                        debugToken = readDebugToken(ctx)
                        tokenShown = true
                    },
                    modifier = Modifier.padding(top = 8.dp)
                ) { Text("Show App Check debug token") }
                if (tokenShown) {
                    val tok = debugToken
                    if (tok == null) {
                        Text(
                            "Token not found yet. Send one chat message first, then try again.",
                            fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
                        )
                    } else {
                        Text(tok, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(tok))
                            toast(ctx, "Copied")
                        }) { Text("Copy token") }
                        Text(
                            "Register it in Firebase console → App Check → Apps → ⋮ → Manage debug tokens. Keep it private.",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 16.dp))
            Text("JARVIS AI v${BuildConfig.VERSION_NAME}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text("Delete ALL history? / সব মুছবেন?") },
            text = { Text("This cannot be undone. / এটি আর ফেরানো যাবে না।") },
            confirmButton = { TextButton(onClick = { vm.deleteAllHistory(); confirmAll = false }) { Text("Delete all") } },
            dismissButton = { TextButton(onClick = { confirmAll = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- Phone actions

@Composable
fun ActionsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val actions = remember { phoneActions(ctx) }
    var selected by remember { mutableStateOf<PhoneAction?>(null) }
    var value by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        TopBar("Phone actions", onBack)
        Text(
            "These buttons open normal Android screens or apps after you confirm. JARVIS cannot control other apps, " +
                "read your screen, place calls, or change settings by itself.\n" +
                "এগুলো আপনার নিশ্চিত করার পর সাধারণ অ্যান্ড্রয়েড স্ক্রিন/অ্যাপ খোলে; JARVIS ফোন নিয়ন্ত্রণ করতে পারে না।",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(actions, key = { it.title }) { a ->
                Card(
                    onClick = { value = ""; selected = a },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(a.title, fontWeight = FontWeight.SemiBold)
                        Text(a.desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    selected?.let { a ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text("Confirm: ${a.title}") },
            text = {
                Column {
                    Text(a.desc)
                    if (a.inputLabel != null) {
                        OutlinedTextField(
                            value = value, onValueChange = { value = it },
                            label = { Text(a.inputLabel) }, singleLine = true,
                            modifier = Modifier.padding(top = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val ok = a.run(ctx, value)
                    selected = null
                    if (!ok) toast(ctx, "Couldn't do that: missing input or no app available. / করা যায়নি: ইনপুট বা অ্যাপ নেই।")
                }) { Text("Confirm / নিশ্চিত") }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Cancel") } }
        )
    }
}
