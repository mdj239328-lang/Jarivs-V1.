package com.jarvis.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** Text-to-speech using the phone's own Android TextToSpeech engine. */
class Speaker(ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false

    var notify: ((String) -> Unit)? = null

    var speaking by mutableStateOf(false)
        private set
    var voices by mutableStateOf<List<Voice>>(emptyList())
        private set

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { speaking = true }
                    override fun onDone(utteranceId: String?) { if (utteranceId?.endsWith("_last") == true) speaking = false }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { speaking = false }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) { speaking = false }
                })
                voices = runCatching {
                    tts?.voices.orEmpty()
                        .filter { it.locale.language == "bn" || it.locale.language == "en" }
                        .sortedBy { it.name }
                }.getOrDefault(emptyList())
            }
        }
    }

    fun speak(text: String, rate: Float, voiceName: String) {
        val t = tts
        if (t == null || !ready) {
            notify?.invoke("Text-to-speech is not ready. / ভয়েস ইঞ্জিন প্রস্তুত নয়।")
            return
        }
        val clean = text.replace(Regex("[*#`_>]"), "").trim()
        if (clean.isEmpty()) return
        val bengali = clean.any { it in 'ঀ'..'৿' }
        val locale = if (bengali) Locale("bn", "BD") else Locale.US
        val chosen = voices.firstOrNull { it.name == voiceName }
        if (chosen != null && chosen.locale.language == locale.language) {
            t.voice = chosen
        } else {
            val r = t.setLanguage(locale)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                notify?.invoke(
                    if (bengali) "এই ফোনে বাংলা ভয়েস ইনস্টল নেই (Settings → Text-to-speech)।"
                    else "English voice is not installed on this phone."
                )
                return
            }
        }
        t.setSpeechRate(rate)
        val maxLen = (TextToSpeech.getMaxSpeechInputLength() - 100).coerceAtLeast(500)
        val chunks = clean.chunked(maxLen)
        chunks.forEachIndexed { i, c ->
            val id = if (i == chunks.lastIndex) "jarvis_${i}_last" else "jarvis_$i"
            t.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
    }

    fun stop() {
        tts?.stop()
        speaking = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

/** Speech-to-text using Android's SpeechRecognizer (needs the Google app / speech service on the phone). */
class Listener(private val ctx: Context) {
    private var rec: SpeechRecognizer? = null

    var listening by mutableStateOf(false)
        private set
    var partial by mutableStateOf("")
        private set

    fun available(): Boolean = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun start(lang: String, onText: (String) -> Unit, onFail: (String) -> Unit) {
        release()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            }

            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                release()
                if (!text.isNullOrBlank()) onText(text) else onFail("কিছু শোনা যায়নি। / Nothing heard.")
            }

            override fun onError(error: Int) {
                release()
                onFail(
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            "কিছু শোনা যায়নি। আবার চেষ্টা করুন। / Nothing heard, try again."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                            "ভয়েস চিনতে ইন্টারনেট লাগে। / Speech recognition needs internet."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            "মাইক্রোফোন অনুমতি নেই। / Microphone permission missing."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                            "রিকগনাইজার ব্যস্ত, একটু পরে চেষ্টা করুন। / Recognizer busy."
                        12, 13 -> "এই ভাষা এই ফোনে সমর্থিত নয়; অন্য ভাষা বা টাইপ করুন। / Language not supported on this phone."
                        else -> "ভয়েস ইনপুট কাজ করেনি (কোড $error)। টাইপ করুন। / Voice input failed (code $error)."
                    }
                )
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        listening = true
        partial = ""
        r.startListening(intent)
    }

    /** Stops recording; the recognizer then delivers whatever it heard. */
    fun stop() {
        rec?.stopListening()
    }

    fun release() {
        rec?.destroy()
        rec = null
        listening = false
        partial = ""
    }
}
